import { unlinkSync } from "fs";
import { extractText } from "../utils/pdfExtractor.js";
import { detectBank } from "../utils/bankDetector.js";
import { parse } from "../utils/transactionParsers.js";
import { classifyTransaction } from "../utils/ollamaClient.js";

export async function parseBankStatement(req, res) {
  try {
    const { user_id } = req.body;
    const filePath = req.file.path;

    // Extract text
    const pdfText = await extractText(filePath);

    // Detect bank
    const bank = detectBank(pdfText);
    if (bank === "Unknown") throw new Error("Unsupported bank format");

    // Parse transactions
    const rawTransactions = parse(pdfText, bank);

    // Classify each transaction using Ollama
    const classified = [];
    for (const tx of rawTransactions) {
      const aiResult = await classifyTransaction(tx);
      classified.push({ ...tx, ...aiResult });
    }

    res.json({ bank, transactions: classified });

    // Clean up uploaded file
    unlinkSync(filePath);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}
