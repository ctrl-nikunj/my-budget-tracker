import { readFileSync } from "fs";

export async function extractText(filePath) {
  const pdfParse = (await import("pdf-parse")).default; // 👈 Lazy import
  const dataBuffer = readFileSync(filePath);
  const data = await pdfParse(dataBuffer);
  return data.text;
}
