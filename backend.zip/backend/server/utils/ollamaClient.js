import axios from "axios";

export async function classifyTransaction(tx) {
  const prompt = `
You are a financial assistant.

Classify this bank transaction:
Date: ${tx.date}
Description: ${tx.description}
Amount: ${tx.amount}
Dr/Cr: ${tx.dr_cr}

Return JSON:
{
  "type": "income | expense | savings | emi | credit",
  "category": "<category>",
  "note": "<short description>"
}
`;

  const res = await axios.post("http://localhost:11434/api/generate", {
    model: "llama3",
    prompt,
  });

  return JSON.parse(res.data.response);
}
