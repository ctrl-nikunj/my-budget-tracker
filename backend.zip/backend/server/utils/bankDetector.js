export function detectBank(text) {
  if (/HDFC Bank/i.test(text)) return "HDFC";
  if (/ICICI Bank/i.test(text)) return "ICICI";
  if (/Bandhan Bank/i.test(text)) return "Bandhan";
  return "Unknown";
}
