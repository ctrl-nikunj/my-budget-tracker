export function parse(text, bank) {
  switch (bank) {
    case "Bandhan":
      return parseBandhan(text);
    case "HDFC":
      return parseHdfc(text);
    case "ICICI":
      return parseIcici(text);
    default:
      throw new Error("Unsupported bank");
  }
}

function parseBandhan(text) {
  const lines = text.split("\n");
  const transactions = [];
  const regex =
    /^(\w+\d{2}, \d{4})\s+\w+\d{2}, \d{4}\s+(.*?)\s+INR([\d,]+\.\d{2})\s+(Dr|Cr)/;

  for (const line of lines) {
    const match = regex.exec(line);
    if (match) {
      transactions.push({
        date: match[1],
        description: match[2].trim(),
        amount: parseFloat(match[3].replace(/,/g, "")),
        dr_cr: match[4],
      });
    }
  }
  return transactions;
}

function parseHdfc(text) {
  /* your HDFC regex */
}
function parseIcici(text) {
  /* your ICICI regex */
}
